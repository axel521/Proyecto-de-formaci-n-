document.getElementById('btn-registro').addEventListener('click', function () {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
    this.classList.add('active');
    document.getElementById('btn-sesion').classList.remove('active');
});

document.getElementById('btn-sesion').addEventListener('click', function () {
    document.getElementById('login-form').style.display = 'block';
    document.getElementById('register-form').style.display = 'none';
    this.classList.add('active');
    document.getElementById('btn-registro').classList.remove('active');
});

document.getElementById("limpiar").addEventListener("click", function() {
    document.querySelectorAll("input").forEach(input => input.value = "");
});

function cancelar() {
    window.location.reload();
}

function actualizarNombreUnidad() {
    // Obtiene el valor seleccionado en el menú desplegable
    var unidadSeleccionada = document.getElementById("unidadSelect").value;
    
    // Actualiza el texto del botón con el nombre de la unidad seleccionada
    var botonUnidad = document.getElementById("unidadButton");
    if (unidadSeleccionada) {
        botonUnidad.textContent = "REGISTRO UNIDAD (" + unidadSeleccionada + ")";
        
        // Genera un código único basado en la unidad seleccionada
        var codigoVenta = unidadSeleccionada.substring(0, 3).toUpperCase() + '-' + Date.now();
        document.getElementById("codigoVenta").value = codigoVenta; // Asigna el código generado al campo de código
    } else {
        botonUnidad.textContent = "REGISTRO UNIDAD (Nombre Unidad)";
    }
}

// Función para guardar los datos en la base de datos
function guardarEnBaseDeDatos(datos) {
    fetch('guardar.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(datos)
    })
    .then(response => response.json())
    .then(data => {
        alert('Datos guardados exitosamente');
    })
    .catch(error => {
        console.error('Error al guardar:', error);
    });
}

// Captura el evento del botón "Guardar"
document.querySelector(".save-btn").addEventListener("click", function(event) {
    event.preventDefault(); // Prevenir el envío del formulario

    // Obtiene los datos de la tabla
    var filas = document.querySelectorAll("table tbody tr");
    var datos = [];

    filas.forEach(function(fila) {
        var filaDatos = {
            codigo: document.getElementById("codigoVenta").value, // Incluye el código generado
            producto: fila.cells[1].innerText,
            unidad: fila.cells[2].innerText,
            cantidad: fila.cells[3].innerText,
            valores: fila.cells[4].innerText
        };
        datos.push(filaDatos);
    });

    // Llama a la función para guardar en la base de datos
    guardarEnBaseDeDatos(datos);
});

function mostrarSegundaVista() {
    // Aquí iría el código para redirigir o mostrar la segunda vista.
    window.location.href = "segunda_vista.html"; // Asegúrate de que este archivo exista y tenga el diseño replicado.
}
function mostrarSegundaVista() {
    // Aquí puedes añadir la lógica para redirigir o mostrar otra vista.
    alert("Redirigiendo a la Segunda Vista");
}

function calcularCambio() {
    const totalPagar = parseFloat(document.getElementById("totalPagar").textContent);
    const pagaCon = parseFloat(document.getElementById("pagaCon").value);
    const cambio = pagaCon - totalPagar;

    document.getElementById("cambio").textContent = cambio >= 0 ? cambio.toFixed(2) : "0.00";
}



// Guardar datos en la base de datos
function guardarEnTabla() {
    const codigo = generarCodigoAleatorio();
    const producto = document.getElementById("producto").value;
    const unidad = document.getElementById("unit").value;
    const cantidad = document.getElementById("cantidad").value;
    const precio_total = document.getElementById("valores").value;
    const entregado_a = document.getElementById("entregadoA").value;
    const recibido_por = document.getElementById("recibidoPor").value;
    const fecha = document.getElementById("fecha").value;

    if (producto && unidad && cantidad && precio_total && entregado_a && recibido_por) {
        fetch("guardar_registro.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: `codigo=${codigo}&producto=${producto}&unidad=${unidad}&cantidad=${cantidad}&precio_total=${precio_total}&entregado_a=${entregado_a}&recibido_por=${recibido_por}&fecha=${fecha}`,
        })
            .then((response) => response.text())
            .then((data) => {
                alert(data);
                cargarRegistros(); // Recargar la tabla
                limpiarFormulario();
            });
    } else {
        alert("Por favor, complete todos los campos.");
    }
}

// Cargar registros en la tabla
function cargarRegistros() {
    fetch("mostrar_registros.php")
        .then((response) => response.text())
        .then((data) => {
            document.getElementById("tabla-registros").innerHTML = data;
        });
}

// Cargar registros al iniciar la página
window.onload = cargarRegistros;





