<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generar Reportes de Ventas</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4a90e2;
            --secondary-color: #f5f6fa;
            --accent-color: #2ecc71;
            --text-color: #2c3e50;
            --sidebar-width: 250px;
            --sidebar-bg: #39465c;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--secondary-color);
            color: var(--text-color);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

    /* Barra lateral mejorada */
    .sidebar {
        width: 280px;
        background: linear-gradient(180deg, #394867 0%, #212A3E 100%);
        color: white;
        padding: 20px;
        position: fixed;
        height: 100vh;
        left: 0;
        top: 0;
        animation: slideIn 0.5s ease-out;
        z-index: 1000;
        position: relative; 
        display: flex;
        flex-direction: column;
    }
    .logout-btn:hover {
        background-color: #c0392b !important;
    }
    .logo {
        text-align: center;
        padding: 20px 0;
        border-bottom: 1px solid rgba(255,255,255,0.1);
        margin-bottom: 30px;
    }

    .logo img {
        width: 60px;
        transition: transform 0.3s ease;
    }

    .logo img:hover {
        transform: scale(1.1);
    }

    .menu-item {
        display: flex;
        align-items: center;
        padding: 15px;
        margin-bottom: 10px;
        color: white;
        text-decoration: none;
        border-radius: 8px;
        transition: all 0.3s ease;
        font-size: 16px;
    }

    .menu-item:hover {
        background-color: rgba(255,255,255,0.1);
        transform: translateX(10px);
    }

    .menu-item i {
        margin-right: 15px;
        font-size: 20px;
    }


        /* Contenido principal */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 2rem;
            background-color: var(--secondary-color);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: var(--shadow);
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 {
            color: var(--primary-color);
            margin-bottom: 2rem;
            text-align: center;
            font-size: 2.5rem;
            position: relative;
        }

        h2::after {
            content: '';
            display: block;
            width: 100px;
            height: 4px;
            background: var(--accent-color);
            margin: 10px auto;
            border-radius: 2px;
        }

        form {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            background: var(--secondary-color);
            padding: 2rem;
            border-radius: 10px;
            margin-bottom: 2rem;
        }

        .input-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        label {
            font-weight: 600;
            color: var(--text-color);
        }

        input[type="date"] {
            padding: 0.8rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        input[type="date"]:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.1);
        }

        button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        button:hover {
            background-color: #357abd;
            transform: translateY(-2px);
        }

        .reporte-info {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border-left: 4px solid var(--primary-color);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 2rem;
            background: white;
            box-shadow: var(--shadow);
            border-radius: 10px;
            overflow: hidden;
        }

        thead {
            background-color: var(--primary-color);
            color: white;
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        tbody tr {
            transition: all 0.3s ease;
        }

        tbody tr:hover {
            background-color: #f8f9fa;
            transform: scale(1.01);
        }

        .empty-message {
            text-align: center;
            padding: 2rem;
            color: #666;
            font-style: italic;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                z-index: 1000;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                width: 100%;
            }

            .container {
                padding: 1rem;
            }
            
            form {
                flex-direction: column;
                align-items: stretch;
            }
            
            table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar">
  <div class="logo">
            <img src="sena-logo.png" alt="SENA">
        </div>
        <a href="../Vendedor.php" class="menu-item">
            <i>✉️</i>
            Recibidos
        </a>
        <a href="reportes.php" class="menu-item">
            <i>📊</i>
            Reportes
        </a>
        <a href="ventas.php" class="menu-item">
            <i>💰</i>
            Ventas
        </a>
        <a href="../InicioUsuario.html" class="menu-item logout-btn" style="margin-top: auto; background-color: #e74c3c; position: absolute; bottom: 20px; left: 20px; right: 20px;">
            <i class="fas fa-sign-out-alt"></i>
            Cerrar Sesión
        </a>
    </div>

    <!-- Contenido Principal -->
    <div class="main-content">
        <div class="container">
            <h2>
                <i class="fas fa-calendar-alt"></i>
                Consulta de Productos por Rango de Fechas
            </h2>

            <form method="POST" action="">
                <div class="input-group">
                    <label for="fecha_inicio">
                        <i class="fas fa-calendar"></i> Desde:
                    </label>
                    <input type="date" id="fecha_inicio" name="fecha_inicio" required>
                </div>
                <div class="input-group">
                    <label for="fecha_fin">
                        <i class="fas fa-calendar"></i> Hasta:
                    </label>
                    <input type="date" id="fecha_fin" name="fecha_fin" required>
                </div>
                <button type="submit">
                    <i class="fas fa-search"></i>
                    Consultar
                </button>
            </form>

<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sena";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Procesar formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fecha_inicio = $_POST['fecha_inicio'];
    $fecha_fin = $_POST['fecha_fin'];

    // Consulta a la tabla de productos
    $sql = "SELECT * FROM productos WHERE fecha BETWEEN ? AND ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $fecha_inicio, $fecha_fin);
    $stmt->execute();
    $result = $stmt->get_result();

    // Mostrar fecha y hora de generación del reporte
    date_default_timezone_set("America/Bogota"); // Ajusta la zona horaria según tu ubicación
    $fecha_actual = date("d-m-Y H:i:s");
    echo "<div class='reporte-info'>
            <strong>Generado:</strong> $fecha_actual
          </div>";

    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<thead>
                <tr>
                    <th>ID</th>
                    <th>Fecha</th>
                    <th>Producto</th>
                    <th>Descripción</th>
                    <th>Cantidad</th>
                    <th>Unidad</th>
                    <th>Precio</th>
                    <th>Total</th>
                </tr>
              </thead>";
        echo "<tbody>";
        while ($row = $result->fetch_assoc()) {
            $precio_cop = number_format($row['precio'],0, ',', '.') . " COP"; // Formato de precio
            $total_cop = number_format($row['total'],0, ',', '.') . " COP";   // Formato de total
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['fecha']}</td>
                    <td>{$row['producto']}</td>
                    <td>{$row['descripcion']}</td>
                    <td>{$row['cantidad']}</td>
                    <td>{$row['unidad']}</td>
                    <td>$precio_cop</td>
                    <td>$total_cop</td>
                  </tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p style='text-align: center;'>No se encontraron registros en el rango de fechas seleccionado.</p>";
    }
    $stmt->close();
}

$conn->close();
?>

</body>
</html>
