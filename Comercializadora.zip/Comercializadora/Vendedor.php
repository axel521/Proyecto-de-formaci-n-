<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sena";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializamos el array de registros temporales si no existe
if (!isset($_SESSION['registros_temporales'])) {
    $_SESSION['registros_temporales'] = array();
}

// Insertar producto
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registrar'])) {
    $fecha = $_POST['fecha'];
    $producto = $_POST['producto'];
    $descripcion = $_POST['descripcion'];
    $cantidad = (int)$_POST['cantidad'];
    $unidad = $_POST['unidad'];
    $precio = (int)$_POST['precio'];
    $total = $cantidad * $precio;

    $sql = "INSERT INTO productos (fecha, producto, descripcion, cantidad, unidad, precio, total) 
            VALUES ('$fecha', '$producto', '$descripcion', '$cantidad', '$unidad', '$precio', '$total')";

    if ($conn->query($sql) === TRUE) {
        // Guardamos el registro en la sesión temporal
        $_SESSION['registros_temporales'][] = array(
            'producto' => $producto,
            'cantidad' => $cantidad,
            'unidad' => $unidad,
            'total' => $total
        );
        echo "<div class='mensaje-exito'><i class='fas fa-check-circle'></i> Producto registrado exitosamente</div>";
    } else {
        echo "<div class='mensaje-error'><i class='fas fa-exclamation-circle'></i> Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}

// Insertar venta
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['completar_venta'])) {
    $total_a_pagar = (int)$_POST['total_a_pagar'];
    $monto_pagado = (int)$_POST['monto_pagado'];
    $cambio = max(0, $monto_pagado - $total_a_pagar);
    $fecha_venta = date('Y-m-d');

    $sql_venta = "INSERT INTO ventas (fecha, total_a_pagar, monto_pagado, cambio) 
                  VALUES ('$fecha_venta', '$total_a_pagar', '$monto_pagado', '$cambio')";

    if ($conn->query($sql_venta) === TRUE) {
        echo "Venta registrada exitosamente";
        $_SESSION['registros_temporales'] = array(); // Limpiamos los registros temporales
    } else {
        echo "Error: " . $sql_venta . "<br>" . $conn->error;
    }
}

// Limpiar los datos de la pantalla
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['limpiar'])) {
    $_SESSION['registros_temporales'] = array(); // Limpiamos los registros temporales
}

// Obtener productos
$sql = "SELECT * FROM productos";
$result = $conn->query($sql);

// Total a pagar
$totalPagar = 0;
foreach ($_SESSION['registros_temporales'] as $registro) {
    $totalPagar += $registro['total'];
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina Cajero</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="CSS/vendedor.css">
    <script>
        function calcularCambio() {
            let total = parseInt(document.getElementById('totalPagar').textContent);
            let pago = parseInt(document.getElementById('pago').value);
            let cambio = pago - total;
            if (cambio < 0) cambio = 0;
            document.getElementById('cambio').textContent = cambio;
            document.getElementById('pagoValue').value = pago;
        }
    </script>
</head>
<body>
<div class="sidebar">
    <div class="logo">
        <img src="sena-logo.png" alt="SENA">
    </div>
    <a href="Vendedor.php" class="menu-item">✉️ Recibidos</a>
    <a href="PHP/reportes.php" class="menu-item">📊 Reportes</a>
    <a href="PHP/ventas.php" class="menu-item">💰 Ventas</a>
    <a href="nuevophp/ver_recibo_vendedor.php" class="menu-item">💰 Recibos</a>
    <a href="InicioUsuario.html" class="menu-item logout-btn" style="margin-top: auto; background-color: #e74c3c; position: absolute; bottom: 20px; left: 20px; right: 20px;">
            <i class="fas fa-sign-out-alt"></i>
            Cerrar Sesión
    </a>
</div>

<div class="main-content">
    <div class="seccion1">
        <h2>Registro de Productos</h2>
        <form method="POST">
            <label for="fecha">Fecha:</label>
            <input type="date" name="fecha" required><br><br>

            <label for="producto">Producto:</label>
            <input type="text" name="producto" required><br><br>

            <label for="descripcion">Descripción:</label>
            <input type="text" name="descripcion" required><br><br>

            <label for="cantidad">Cantidad:</label>
            <input type="number" name="cantidad" required><br><br>

            <label for="unidad">Unidad:</label>
            <select name="unidad" required>
                <option value="KG">KG</option>
                <option value="L">L</option>
                <option value="Uds">Uds</option>
            </select><br><br>

            <label for="precio">Precio (COP):</label>
            <input type="number" name="precio" required><br><br>

            <button type="submit" name="registrar" id="registrar"><i class="fas fa-plus"></i> Registrar Producto</button>
        </form>

        <form method="POST">
            <button type="submit" name="limpiar" id="limpiar"><i class="fas fa-trash"></i> Limpiar Pantalla</button>
        </form>
    </div>

    <div class="seccion2">
    <h2>Productos Registrados</h2>
    <?php if (!empty($_SESSION['registros_temporales'])): ?>
        <table>
            <thead>
                <tr>
                    <th>N.</th>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Unidad</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $index = 1;
                foreach ($_SESSION['registros_temporales'] as $registro) {
                    echo "<tr>
                            <td>" . $index++ . "</td>
                            <td>" . $registro['producto'] . "</td>
                            <td>" . $registro['cantidad'] . "</td>
                            <td>" . $registro['unidad'] . "</td>
                            <td>" . $registro['total'] . " COP</td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No hay registros para mostrar.</p>
    <?php endif; ?>
</div>

    <div class="seccion3">
        <h2>Pago</h2>
        <p>Total a Pagar: <span id="totalPagar"><?php echo $totalPagar; ?></span> COP</p>

        <label for="pago">Monto con el que paga:</label>
        <input type="number" id="pago" oninput="calcularCambio()" required><br><br>

        <p>Cambio: <span id="cambio">0</span> COP</p>

        <form method="POST">
            <input type="hidden" name="total_a_pagar" value="<?php echo $totalPagar; ?>">
            <input type="hidden" name="monto_pagado" id="pagoValue" value="" required>
            <button type="submit" name="completar_venta" id="completar"><i class="fas fa-check"></i> Completar Venta</button>
        </form>
    </div>
</div>
</body>
</html>

<?php
$conn->close();
?>