<?php
// guardar.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datos = json_decode(file_get_contents('php://input'), true);

    // Conexión a la base de datos
    $conexion = new mysqli('localhost', 'usuario', 'contraseña', 'comerczldra');

    if ($conexion->connect_error) {
        die('Conexión fallida: ' . $conexion->connect_error);
    }

    foreach ($datos as $dato) {
        // Consulta SQL para insertar los datos
        $producto = $dato['producto'];
        $unidad = $dato['unidad'];
        $cantidad = $dato['cantidad'];
        $valores = $dato['valores'];

        $consulta = "INSERT INTO ventas (producto, unidad, cantidad, valores) VALUES ('$producto', '$unidad', '$cantidad', '$valores')";
        
        if (!$conexion->query($consulta)) {
            echo 'Error al guardar: ' . $conexion->error;
        }
    }

    $conexion->close();
    echo json_encode(['mensaje' => 'Datos guardados']);
}
?>
<?php
// guardar.php

// Recibe los datos del formulario
$data = json_decode(file_get_contents('php://input'), true);

// Establece la conexión con la base de datos
$mysqli = new mysqli("localhost", "usuario", "contraseña", "base_de_datos");

// Verifica la conexión
if ($mysqli->connect_error) {
    die("Conexión fallida: " . $mysqli->connect_error);
}

// Inserta los datos en la base de datos
foreach ($data as $item) {
    $codigo = $mysqli->real_escape_string($item['codigo']);
    $producto = $mysqli->real_escape_string($item['producto']);
    $unidad = $mysqli->real_escape_string($item['unidad']);
    $cantidad = $mysqli->real_escape_string($item['cantidad']);
    $valores = $mysqli->real_escape_string($item['valores']);

    $query = "INSERT INTO ventas (codigo, producto, unidad, cantidad, valores) 
              VALUES ('$codigo', '$producto', '$unidad', '$cantidad', '$valores')";

    if (!$mysqli->query($query)) {
        echo "Error al guardar: " . $mysqli->error;
    }
}

$mysqli->close();
echo json_encode(["status" => "success"]);
?>
