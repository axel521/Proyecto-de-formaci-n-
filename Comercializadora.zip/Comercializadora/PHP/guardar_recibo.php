<?php
include "db.php";
//NOOOOOOOO TOCAAAAAAAAAAAAR
// Verifica si los datos llegan correctamente
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo = $_POST['codigo'] ?? '';
    $fecha = $_POST['fecha'] ?? '';
    $entregadoA = $_POST['entregadoA'] ?? '';
    $producto = $_POST['producto'] ?? '';
    $recibidoDe = $_POST['recibidoDe'] ?? '';
    $cantidad = $_POST['cantidad'] ?? 0;
    $pUnit = $_POST['pUnit'] ?? 0;
    $valores = $_POST['valores'] ?? 0;

    // Mostrar datos recibidos para depurar
    echo "Datos recibidos: <br>";
    echo "Código: $codigo<br>";
    echo "Fecha: $fecha<br>";
    echo "Entregado a: $entregadoA<br>";
    echo "Producto: $producto<br>";
    echo "Recibido de: $recibidoDe<br>";
    echo "Cantidad: $cantidad<br>";
    echo "P/Unit: $pUnit<br>";
    echo "Valores: $valores<br>";

    $sql = "INSERT INTO recibos (codigo, fecha, entregado_a, producto, recibido_de, cantidad, p_unit, valores)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error en la preparación del statement: " . $conn->error);
    }

    $stmt->bind_param("ssssssss", $codigo, $fecha, $entregadoA, $producto, $recibidoDe, $cantidad, $pUnit, $valores);

    if ($stmt->execute()) {
        echo "Recibo guardado con éxito.";
    } else {
        echo "Error al guardar el recibo: " . $stmt->error;
    }

    $stmt->close();
}
$conn->close();
?>
