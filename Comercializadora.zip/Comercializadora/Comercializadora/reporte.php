<?php
// reporte.php

// Aquí se incluyen las conexiones a la base de datos y recuperación de datos.
$desde = isset($_POST['desde']) ? $_POST['desde'] : '';
$hasta = isset($_POST['hasta']) ? $_POST['hasta'] : '';

// Conectar a la base de datos
$servername = "localhost";
$username = "usuario";
$password = "contraseña";
$dbname = "comerczldra";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$sql = "SELECT * FROM registros WHERE fecha >= '$desde' AND fecha <= '$hasta'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte Generado</title>
    <link rel="stylesheet" href="reporte.css"> <!-- Agrega un archivo CSS específico -->
</head>
<body>
    <div class="container">
        <header>    
            <h1>Reporte Generado</h1>
        </header>
        <section class="report-section">
            <h2>Detalles del Reporte</h2>

            <!-- Tabla para mostrar el reporte -->
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Fecha</th>
                        <th>Valor</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        // Mostrar los registros encontrados
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>" . $row["id"] . "</td>
                                <td>" . $row["nombre"] . "</td>
                                <td>" . $row["fecha"] . "</td>
                                <td>" . $row["valor"] . "</td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No se encontraron registros para el periodo seleccionado.</td></tr>";
                    }
                    $conn->close();
                    ?>
                </tbody>
            </table>
            <br>
            <!-- Opcional: un botón para volver a la página anterior o al menú -->
            <button onclick="window.location.href='reportes.html'">Volver</button>
        </section>
    </div>
</body>
</html>

