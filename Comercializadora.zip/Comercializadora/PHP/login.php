<?php 
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipoDocumento = $_POST['document-type'];
    $documento = $_POST['document'];
    $contraseña = $_POST['password'];

    // Consulta para verificar el usuario
    $sql = "SELECT ID_Usuario, Nombre, Contraseña, Rol FROM usuarios WHERE Tipo_Documento = ? AND Documento = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $tipoDocumento, $documento);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Verificar la contraseña
        $user = $result->fetch_assoc();
        if (password_verify($contraseña, $user['Contraseña'])) {
            // Redirigir según el rol
            if ($user['Rol'] == 'admin') {
                header("Location: ../Admin_pagina.html");
            } else if ($user['Rol'] == 'vendedor') {
                header("Location: ../Vendedor.php");
            }
        } else {
            echo "Contraseña incorrecta.";
        }
    } else {
        echo "Usuario no encontrado.";
    }

    $stmt->close();
}
$conn->close();
?>