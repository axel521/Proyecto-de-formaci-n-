document.addEventListener("DOMContentLoaded", () => {
    const cantidad = document.getElementById("cantidad");
    const pUnit = document.getElementById("pUnit");
    const valores = document.getElementById("valores");
    const tablaRecibos = document.getElementById("tabla-recibos").querySelector("tbody");

    // Calcular valores automáticamente
    cantidad.addEventListener("input", calcularValores);
    pUnit.addEventListener("input", calcularValores);

    function calcularValores() {
        if (cantidad.value && pUnit.value) {
            valores.value = (cantidad.value * pUnit.value).toFixed(2);
        }
    }

// Limpiar formulario con animación
document.getElementById('nuevo').addEventListener('click', function() {
    const form = document.getElementById('registro-form');
    form.style.opacity = '0.5';
    setTimeout(() => {
        form.reset();
        form.style.opacity = '1';
    }, 300);
});

    // Botón "Guardar" para agregar fila a la tabla y guardar en la base de datos
    document.getElementById("guardar").addEventListener("click", () => {
        const producto = document.getElementById("producto").value;
        const unit = pUnit.value;
        const cantidadValor = cantidad.value;
        const total = valores.value;

        if (producto && unit && cantidadValor && total) {
            // Agregar a la tabla
            const fila = document.createElement("tr");
            fila.innerHTML = `
                <td>${tablaRecibos.rows.length + 1}</td>
                <td>${producto}</td>
                <td>${unit}</td>
                <td>${cantidadValor}</td>
                <td>${total}</td>
            `;
            tablaRecibos.appendChild(fila);

            // Guardar en la base de datos (AJAX)
            fetch("PHP/guardar_recibo.php", {
                method: "POST",
                body: new FormData(document.getElementById("registro-form")),
            })
                .then((response) => response.text())
                .then((data) => alert(data))
                .catch((error) => console.error("Error:", error));
        } else {
            alert("Complete todos los campos antes de guardar.");
        }
    });

    // Botón "Cancelar" para limpiar todo
    document.getElementById("cancelar").addEventListener("click", () => {
        tablaRecibos.innerHTML = "";
    });
});

// Función para mostrar mensajes
function mostrarMensaje(mensaje, tipo) {
    const mensajeDiv = document.createElement('div');
    mensajeDiv.className = `mensaje ${tipo}`;
    mensajeDiv.textContent = mensaje;
    mensajeDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        border-radius: 8px;
        color: white;
        animation: slideIn 0.5s ease-out;
        z-index: 1000;
    `;
    
    if (tipo === 'success') {
        mensajeDiv.style.backgroundColor = '#4CAF50';
    } else {
        mensajeDiv.style.backgroundColor = '#f44336';
    }
    
    document.body.appendChild(mensajeDiv);
    
    setTimeout(() => {
        mensajeDiv.style.animation = 'fadeOut 0.5s ease-out';
        setTimeout(() => mensajeDiv.remove(), 500);
    }, 3000);
}