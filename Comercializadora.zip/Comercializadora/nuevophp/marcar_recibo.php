<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productos = $_POST['productos']; // Array con los productos marcados

    try {
        // Actualizamos el estado de cada producto
        foreach ($productos as $producto_id => $estado) {
            // Si el producto no tiene un estado (es decir, no ha sido marcado), lo marcamos como no recibido (0)
            $estado = ($estado == '1') ? 1 : 0;

            // Verificamos si el producto ya tiene un estado registrado, de lo contrario lo insertamos
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM estado_recibo WHERE producto_id = ?");
            $stmt->execute([$producto_id]);
            $exists = $stmt->fetchColumn();

            if ($exists) {
                // Si existe, actualizamos
                $stmt_update = $pdo->prepare("UPDATE estado_recibo SET recibido = ? WHERE producto_id = ?");
                $stmt_update->execute([$estado, $producto_id]);
            } else {
                // Si no existe, lo insertamos
                $stmt_insert = $pdo->prepare("INSERT INTO estado_recibo (producto_id, recibido) VALUES (?, ?)");
                $stmt_insert->execute([$producto_id, $estado]);
            }
        }

        echo json_encode(['message' => 'Estado de los productos actualizado con éxito.']);
    } catch (PDOException $e) {
        echo json_encode(['message' => 'Error al actualizar el estado de los productos: ' . $e->getMessage()]);
    }
}
?>
